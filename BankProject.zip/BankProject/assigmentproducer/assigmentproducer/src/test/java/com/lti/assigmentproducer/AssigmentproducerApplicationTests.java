package com.lti.assigmentproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssigmentproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
