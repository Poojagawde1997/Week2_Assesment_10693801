package com.lti.assigmentproducer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.assigmentproducer.Exception.ResourceNotFoundException;
import com.lti.assigmentproducer.Model.Bank;
import com.lti.assigmentproducer.Repository.BankRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import java.util.*;

@RestController
@RequestMapping("/api")
public class BankController {
	
	@Autowired
	BankRepository bankrepo;
	
	@PostMapping("/addbankcustomer")
	public Bank addProduct(@RequestBody Bank bank) {
		return bankrepo.save(bank);
	}
	
	@GetMapping("/getbankcustomer")
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public List<Bank> getbank(){
		List<Bank> banklist=new ArrayList<Bank>();
		bankrepo.findAll().forEach(b->banklist.add(b));
		return banklist;
	}
	
	@DeleteMapping("/deletebankcustomer/{id}")
	public String deletebank(@PathVariable ("id") long id) throws ResourceNotFoundException {
		Bank bank=bankrepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("Bank Customer with id :"+id+"not found"));
		bankrepo.deleteById(id);
		return "bank customer details deleted with id :"+id;
	}
	
	@PutMapping("/updatebankcustomer/{id}")
	public ResponseEntity<Bank> updateproduct(@PathVariable ("id")long id,@RequestBody Bank bank) throws ResourceNotFoundException {
		
		Bank bank1=bankrepo.findById(id).orElseThrow(()->new ResourceNotFoundException("No Customer to update with id :"+id));
		bank1.setName(bank.getName());
		bank1.setAge(bank.getAge());
		bank1.setAddress(bank.getAddress());
		bank1.setTypeofacc(bank.getTypeofacc());
		final Bank updatedbankcust = bankrepo.save(bank1);

		return ResponseEntity.ok(updatedbankcust);
		 
	}

	
public List<Bank> getDataFallBack() {
		
		List<Bank> list=new ArrayList<Bank>();
		Bank bank = new Bank();
		bank.setId(1);
		bank.setName("fallback-name");
		bank.setAge(0);
		bank.setAddress("fallback-address");
		bank.setTypeofacc("fallback-accounttype");
		list.add(bank);
		return list;
		
	}
}
